# My_investment
A simple example library.
## Installation
```sh
pip install my_investment
```
## Usage
```python
from my_investment import hello_world
print(hello_world())
```
